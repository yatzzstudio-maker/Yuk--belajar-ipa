# Yuk!BelajarIPA

Platform edukasi sains untuk jenjang SD, SMP, SMA, dan perguruan tinggi.
Dikembangkan oleh Yatzz Studio menggunakan Flutter.

## Status
Fondasi UI tahap 1. Aplikasi sudah memiliki navigasi responsif dan halaman awal.
Backend online (Supabase), autentikasi, konten kurikulum, kuis tersimpan, dan AI Tutor
belum dihubungkan pada tahap ini.

## Menjalankan
1. Install Flutter SDK dan Android Studio (untuk Android).
2. Ekstrak proyek.
3. Jalankan `flutter pub get`.
4. Untuk Android: `flutter run`.
5. Untuk Web: `flutter run -d chrome`.
6. Untuk Windows desktop: aktifkan dukungan Windows desktop pada Flutter, lalu `flutter run -d windows`.

## Struktur
- `lib/core/` tema dan konstanta aplikasi.
- `lib/features/` halaman berdasarkan fitur.
- `lib/shared/` komponen UI bersama.

## Roadmap
1. Fondasi UI dan navigasi (folder ini).
2. Autentikasi dan profil pengguna dengan Supabase Auth.
3. Database kurikulum: jenjang > kelas/semester > mata pelajaran > bab > materi.
4. Modul pembelajaran dan progres.
5. Kuis, penilaian, dan pembahasan.
6. Laboratorium virtual.
7. AI Tutor dengan backend aman.
8. Panel admin untuk mengelola materi dan soal.
9. Pengujian, keamanan, aksesibilitas, dan rilis.

## Catatan keamanan
Jangan pernah menaruh Supabase `service_role` key atau secret API di aplikasi Flutter.
Gunakan anon/publishable key dengan Row Level Security (RLS), dan panggil layanan AI
melalui backend/server function.
