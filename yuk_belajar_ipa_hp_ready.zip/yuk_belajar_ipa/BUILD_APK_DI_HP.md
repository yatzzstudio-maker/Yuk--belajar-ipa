# Membuat APK Yuk!BelajarIPA dari HP

1. Buat akun / masuk ke https://github.com.
2. Buat repository baru bernama `yuk-belajar-ipa`.
3. Ekstrak ZIP ini di HP.
4. Buka repository di GitHub melalui browser.
5. Pilih Add file > Upload files, lalu unggah isi folder proyek (termasuk folder `.github`).
   Jika folder tersembunyi tidak terlihat, aktifkan opsi menampilkan file tersembunyi di pengelola file.
6. Commit ke branch `main`.
7. Buka tab Actions pada repository.
8. Pilih workflow `Build Yuk Belajar IPA APK` lalu tekan Run workflow jika workflow belum berjalan otomatis.
9. Tunggu sampai job selesai dengan tanda centang hijau.
10. Buka hasil workflow, cari bagian Artifacts, lalu unduh `yuk-belajar-ipa-android`.
11. Ekstrak artifact ZIP dan instal `app-release.apk` di Android.

Catatan:
- GitHub Actions menjalankan proses build di cloud; HP tidak perlu mengompilasi Flutter.
- Jangan pernah mengunggah password, token, atau secret API ke repository.
- Ini menghasilkan APK dari fondasi UI tahap awal. Backend, login, materi lengkap, kuis tersimpan, dan AI Tutor masih perlu dikembangkan.
