import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1100),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Color(0xFFE2F3FC),
                      child: Icon(Icons.biotech_rounded, color: AppTheme.primary),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(child: Text('Yuk!BelajarIPA', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.navy))),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded)),
                  ],
                ),
                const SizedBox(height: 28),
                const Text('Halo, Penjelajah Sains! 👋', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppTheme.navy)),
                const SizedBox(height: 8),
                const Text('Sains jadi lebih mudah saat dipelajari bersama.', style: TextStyle(color: AppTheme.muted, fontSize: 15)),
                const SizedBox(height: 24),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF168ACB), Color(0xFF47B6D9)]),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('MULAI PETUALANGANMU', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, letterSpacing: 1)),
                      SizedBox(height: 10),
                      Text('Dunia sains menunggumu.', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Text('Pilih topik, pelajari konsep, lalu uji pemahamanmu.', style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                const _SectionTitle(title: 'Jelajahi cabang ilmu', action: 'Lihat semua'),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: const [
                    _SubjectTile(icon: Icons.eco_rounded, title: 'Biologi', color: Color(0xFFE7F7ED)),
                    _SubjectTile(icon: Icons.bolt_rounded, title: 'Fisika', color: Color(0xFFFFF3D9)),
                    _SubjectTile(icon: Icons.science_rounded, title: 'Kimia', color: Color(0xFFECE9FF)),
                    _SubjectTile(icon: Icons.public_rounded, title: 'Astronomi', color: Color(0xFFE2F2FC)),
                    _SubjectTile(icon: Icons.landscape_rounded, title: 'Geologi', color: Color(0xFFFFEDE4)),
                    _SubjectTile(icon: Icons.water_drop_rounded, title: 'Ekologi', color: Color(0xFFE1F7F5)),
                  ],
                ),
                const SizedBox(height: 28),
                const _SectionTitle(title: 'Perjalanan belajarmu'),
                const SizedBox(height: 14),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('Progres belajar', style: TextStyle(fontWeight: FontWeight.bold)),
                          Text('0%', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold)),
                        ]),
                        const SizedBox(height: 12),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: const LinearProgressIndicator(value: 0, minHeight: 9, backgroundColor: Color(0xFFEAF0F5)),
                        ),
                        const SizedBox(height: 8),
                        const Text('Mulai satu materi untuk mencatat progresmu.', style: TextStyle(color: AppTheme.muted)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, this.action});
  final String title;
  final String? action;

  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: AppTheme.navy)),
      if (action != null) Text(action!, style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w600)),
    ],
  );
}

class _SubjectTile extends StatelessWidget {
  const _SubjectTile({required this.icon, required this.title, required this.color});
  final IconData icon;
  final String title;
  final Color color;

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 155,
    child: Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(backgroundColor: color, child: Icon(icon, color: AppTheme.navy)),
            const SizedBox(height: 12),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.navy)),
          ],
        ),
      ),
    ),
  );
}
