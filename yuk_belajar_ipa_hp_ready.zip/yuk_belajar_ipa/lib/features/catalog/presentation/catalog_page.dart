import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class CatalogPage extends StatelessWidget {
  const CatalogPage({super.key});

  @override
  Widget build(BuildContext context) {
    final levels = [
      ('SD Kelas 1–3', 'Mengenal makhluk hidup, benda, dan lingkungan'),
      ('SD Kelas 4–6', 'Tubuh manusia, energi, bumi, dan tata surya'),
      ('SMP Kelas 7–9', 'Konsep dasar biologi, fisika, dan kimia'),
      ('SMA Kelas 10–12', 'Pendalaman konsep dan persiapan kuliah'),
      ('Perguruan Tinggi', 'Materi berdasarkan bidang studi dan semester'),
    ];
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('Jelajahi materi', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: AppTheme.navy)),
          const SizedBox(height: 8),
          const Text('Pilih jenjang pendidikan untuk menemukan materi yang sesuai.', style: TextStyle(color: AppTheme.muted)),
          const SizedBox(height: 20),
          TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Cari mata pelajaran atau topik...'),
          ),
          const SizedBox(height: 20),
          ...levels.map((level) => Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              leading: const CircleAvatar(backgroundColor: Color(0xFFE2F3FC), child: Icon(Icons.school_outlined, color: AppTheme.primary)),
              title: Text(level.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(level.$2)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {},
            ),
          )),
        ],
      ),
    );
  }
}
