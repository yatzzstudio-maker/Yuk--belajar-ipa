import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(
      padding: const EdgeInsets.all(24),
      children: const [
        Text('Profil belajar', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: AppTheme.navy)),
        SizedBox(height: 22),
        CircleAvatar(radius: 38, backgroundColor: Color(0xFFE2F3FC), child: Icon(Icons.person, size: 42, color: AppTheme.primary)),
        SizedBox(height: 12),
        Center(child: Text('Penjelajah Sains', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
        Center(child: Text('Masuk untuk menyimpan progres belajarmu', style: TextStyle(color: AppTheme.muted))),
        SizedBox(height: 24),
        Card(child: ListTile(leading: Icon(Icons.school_outlined), title: Text('Jenjang pendidikan'), subtitle: Text('Belum dipilih'), trailing: Icon(Icons.chevron_right))),
        Card(child: ListTile(leading: Icon(Icons.emoji_events_outlined), title: Text('Pencapaian'), subtitle: Text('Belum ada pencapaian'))),
        Card(child: ListTile(leading: Icon(Icons.settings_outlined), title: Text('Pengaturan'), trailing: Icon(Icons.chevron_right))),
        SizedBox(height: 16),
        Center(child: Text('Yuk!BelajarIPA • Yatzz Studio • v0.1.0', style: TextStyle(color: AppTheme.muted, fontSize: 12))),
      ],
    ),
  );
}
