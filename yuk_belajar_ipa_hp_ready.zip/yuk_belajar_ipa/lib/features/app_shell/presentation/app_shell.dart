import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../home/presentation/home_page.dart';
import '../../catalog/presentation/catalog_page.dart';
import '../../lab/presentation/lab_page.dart';
import '../../profile/presentation/profile_page.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;

  final pages = const [
    HomePage(),
    CatalogPage(),
    LabPage(),
    ProfilePage(),
  ];

  final destinations = const [
    NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Beranda'),
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Belajar'),
    NavigationDestination(icon: Icon(Icons.science_outlined), selectedIcon: Icon(Icons.science), label: 'Lab Sains'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 760;
        return Scaffold(
          body: Row(
            children: [
              if (wide)
                NavigationRail(
                  selectedIndex: selectedIndex,
                  onDestinationSelected: (value) => setState(() => selectedIndex = value),
                  labelType: NavigationRailLabelType.all,
                  backgroundColor: Colors.white,
                  leading: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 28),
                    child: Icon(Icons.biotech_rounded, color: AppTheme.primary, size: 34),
                  ),
                  destinations: destinations.map((item) => NavigationRailDestination(
                    icon: item.icon,
                    selectedIcon: item.selectedIcon,
                    label: Text(item.label),
                  )).toList(),
                ),
              Expanded(child: pages[selectedIndex]),
            ],
          ),
          bottomNavigationBar: wide ? null : NavigationBar(
            selectedIndex: selectedIndex,
            onDestinationSelected: (value) => setState(() => selectedIndex = value),
            destinations: destinations,
          ),
        );
      },
    );
  }
}
