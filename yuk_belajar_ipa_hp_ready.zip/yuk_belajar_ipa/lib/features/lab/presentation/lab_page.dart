import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class LabPage extends StatelessWidget {
  const LabPage({super.key});

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(
      padding: const EdgeInsets.all(24),
      children: const [
        Text('Laboratorium Sains', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: AppTheme.navy)),
        SizedBox(height: 8),
        Text('Belajar melalui simulasi interaktif yang aman.', style: TextStyle(color: AppTheme.muted)),
        SizedBox(height: 22),
        _LabCard(icon: Icons.bolt, title: 'Rangkaian listrik', description: 'Kenali arus, tegangan, dan hambatan.', tag: 'Fisika'),
        _LabCard(icon: Icons.science, title: 'Reaksi dan larutan', description: 'Pelajari campuran, larutan, dan reaksi kimia.', tag: 'Kimia'),
        _LabCard(icon: Icons.biotech, title: 'Sel dan organel', description: 'Jelajahi bagian sel dan fungsinya.', tag: 'Biologi'),
        SizedBox(height: 12),
        Text('Simulasi akan dikembangkan pada tahap laboratorium virtual.', style: TextStyle(color: AppTheme.muted)),
      ],
    ),
  );
}

class _LabCard extends StatelessWidget {
  const _LabCard({required this.icon, required this.title, required this.description, required this.tag});
  final IconData icon;
  final String title;
  final String description;
  final String tag;

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: ListTile(
      contentPadding: const EdgeInsets.all(16),
      leading: CircleAvatar(backgroundColor: const Color(0xFFE2F3FC), child: Icon(icon, color: AppTheme.primary)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('$description\n$tag'),
      isThreeLine: true,
      trailing: const Icon(Icons.lock_outline, color: AppTheme.muted),
    ),
  );
}
