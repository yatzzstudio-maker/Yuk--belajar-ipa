import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'features/app_shell/presentation/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const YukBelajarIpaApp());
}

class YukBelajarIpaApp extends StatelessWidget {
  const YukBelajarIpaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yuk!BelajarIPA',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const AppShell(),
    );
  }
}
